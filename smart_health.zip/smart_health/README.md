# Smart Health Prediction System

A simple web-based health prediction system built with PHP and MySQL for beginner students.

## Features

- User Registration & Login
- Symptom Selection
- Disease Prediction based on symptoms
- Doctor Information
- Admin Panel for managing:
  - Symptoms
  - Diseases
  - Doctors
  - Disease-Symptom Mappings

## Technologies Used

- Frontend: HTML, CSS, Bootstrap 5
- Backend: PHP
- Database: MySQL
- Server: Apache (XAMPP/WAMP)

## Installation Instructions

### Step 1: Install XAMPP
1. Download and install XAMPP from https://www.apachefriends.org/
2. Start Apache and MySQL services from XAMPP Control Panel

### Step 2: Setup Project Files
1. Copy the `smart_health` folder to `C:\xampp\htdocs\`
2. Your project path should be: `C:\xampp\htdocs\smart_health\`

### Step 3: Create Database
1. Open browser and go to: http://localhost/phpmyadmin
2. Click on "New" to create a new database
3. Name it: `smart_health`
4. Click on "Import" tab
5. Choose the `database.sql` file from the project folder
6. Click "Go" to import

Alternative: You can also copy-paste the SQL queries from `database.sql` file into the SQL tab in phpMyAdmin.

### Step 4: Configure Database Connection
1. Open `config/db.php`
2. Update database credentials if needed:
   ```php
   $host = 'localhost';
   $dbname = 'smart_health';
   $username = 'root';
   $password = ''; // Leave empty for XAMPP default
   ```

### Step 5: Run the Project
1. Open browser
2. Visit: http://localhost/smart_health/
3. The homepage will appear

## Default Login Credentials

### Admin Login
- URL: http://localhost/smart_health/admin/login.php
- Username: `admin`
- Password: `admin123`

### User Login
- First register a new user at: http://localhost/smart_health/user/register.php
- Then login with your credentials

## Project Structure

```
smart_health/
│
├── admin/              # Admin panel files
│   ├── login.php
│   ├── dashboard.php
│   ├── add_symptom.php
│   ├── view_symptoms.php
│   ├── add_disease.php
│   ├── view_diseases.php
│   ├── add_doctor.php
│   ├── view_doctors.php
│   ├── map_disease_symptom.php
│   └── view_mapping.php
│
├── config/             # Database configuration
│   └── db.php
│
├── css/                # Stylesheets
│   └── style.css
│
├── includes/           # Reusable components
│   ├── header.php
│   └── footer.php
│
├── user/               # User module
│   ├── register.php
│   ├── login.php
│   ├── select_symptoms.php
│   └── result.php
│
├── doctor/             # Doctor module
│   └── view_doctors.php
│
├── index.php           # Homepage
├── contact.php         # Contact page
├── logout.php          # Logout functionality
└── database.sql        # Database SQL file
```

## How to Use

### For Users:
1. Register a new account
2. Login with your credentials
3. Select symptoms you are experiencing
4. Click "Get Prediction"
5. View the predicted disease and description
6. View available doctors for consultation

### For Admin:
1. Login with admin credentials
2. Manage Symptoms:
   - Add new symptoms
   - View all symptoms
   - Delete symptoms
3. Manage Diseases:
   - Add new diseases with descriptions
   - View all diseases
   - Delete diseases
4. Manage Doctors:
   - Add doctor information
   - View all doctors
   - Delete doctors
5. Map Disease-Symptoms:
   - Link symptoms to diseases
   - View existing mappings
   - Delete mappings

## Database Tables

1. **users** - Stores user information
2. **admin** - Stores admin credentials
3. **symptoms** - Stores all symptoms
4. **diseases** - Stores disease information
5. **doctors** - Stores doctor details
6. **disease_symptom** - Maps diseases to symptoms (many-to-many relationship)

## Prediction Logic

The system uses a simple SQL-based prediction:
1. User selects multiple symptoms
2. System queries the `disease_symptom` table
3. Finds the disease with maximum matching symptoms
4. Returns the disease with highest match count
5. Displays disease name and description to user

## Important Notes

- This is a beginner-level project for learning PHP
- Not suitable for actual medical diagnosis
- Always consult a real doctor for health issues
- Predictions are based only on predefined data in database
- No AI or Machine Learning is used

## Troubleshooting

**Problem: Can't connect to database**
- Solution: Make sure MySQL is running in XAMPP
- Check database credentials in `config/db.php`

**Problem: Page not found (404)**
- Solution: Make sure project is in `htdocs` folder
- URL should be: http://localhost/smart_health/

**Problem: Import database fails**
- Solution: Create database manually first
- Then import the SQL file
- Or copy-paste SQL queries directly

## Future Enhancements

- Machine Learning integration
- Online doctor consultation
- Appointment booking
- Medical history tracking
- Email/SMS notifications
- Multi-language support

## Author

Created by: Ankita Kumari
Project: Smart Health Prediction System
Purpose: Learning PHP & MySQL

## License

This is an educational project. Free to use for learning purposes.
