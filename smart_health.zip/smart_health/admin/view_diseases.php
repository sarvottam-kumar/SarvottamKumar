<?php
$css_path = '../css/style.css';
$home_path = '../index.php';
$base_path = '../';
include '../includes/header.php';
include '../config/db.php';

if(!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit();
}

// Handle delete
if(isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $stmt = $conn->prepare("DELETE FROM diseases WHERE disease_id = ?");
    $stmt->execute([$id]);
    header('Location: view_diseases.php');
    exit();
}

$stmt = $conn->query("SELECT * FROM diseases ORDER BY disease_name");
$diseases = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="container mt-4">
    <h2 class="text-center mb-4">All Diseases</h2>
    
    <table class="table table-bordered">
        <thead class="table-dark">
            <tr>
                <th>ID</th>
                <th>Disease Name</th>
                <th>Description</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach($diseases as $disease): ?>
                <tr>
                    <td><?php echo $disease['disease_id']; ?></td>
                    <td><?php echo htmlspecialchars($disease['disease_name']); ?></td>
                    <td><?php echo htmlspecialchars($disease['description']); ?></td>
                    <td>
                        <a href="?delete=<?php echo $disease['disease_id']; ?>" 
                           class="btn btn-danger btn-sm" 
                           onclick="return confirm('Are you sure?')">Delete</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    
    <a href="dashboard.php" class="btn btn-secondary">Back to Dashboard</a>
</div>

<?php include '../includes/footer.php'; ?>
