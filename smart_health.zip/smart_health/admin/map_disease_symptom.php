<?php
$css_path = '../css/style.css';
$home_path = '../index.php';
$base_path = '../';
include '../includes/header.php';
include '../config/db.php';

if(!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit();
}

$message = '';

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $disease_id = $_POST['disease_id'];
    $symptom_ids = $_POST['symptoms'];
    
    try {
        foreach($symptom_ids as $symptom_id) {
            $stmt = $conn->prepare("INSERT INTO disease_symptom (disease_id, symptom_id) VALUES (?, ?)");
            $stmt->execute([$disease_id, $symptom_id]);
        }
        $message = '<div class="alert alert-success">Mapping added successfully!</div>';
    } catch(PDOException $e) {
        $message = '<div class="alert alert-danger">Error: Mapping may already exist!</div>';
    }
}

$diseases = $conn->query("SELECT * FROM diseases ORDER BY disease_name")->fetchAll(PDO::FETCH_ASSOC);
$symptoms = $conn->query("SELECT * FROM symptoms ORDER BY symptom_name")->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="container mt-4">
    <h2 class="text-center mb-4">Map Disease with Symptoms</h2>
    <?php echo $message; ?>
    
    <div class="card" style="max-width: 700px; margin: 0 auto;">
        <div class="card-body">
            <form method="POST">
                <div class="mb-3">
                    <label>Select Disease</label>
                    <select name="disease_id" class="form-control" required>
                        <option value="">Choose Disease</option>
                        <?php foreach($diseases as $disease): ?>
                            <option value="<?php echo $disease['disease_id']; ?>">
                                <?php echo htmlspecialchars($disease['disease_name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="mb-3">
                    <label>Select Symptoms (multiple)</label>
                    <div class="border p-3" style="max-height: 300px; overflow-y: auto;">
                        <?php foreach($symptoms as $symptom): ?>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" name="symptoms[]" 
                                       value="<?php echo $symptom['symptom_id']; ?>" 
                                       id="symptom<?php echo $symptom['symptom_id']; ?>">
                                <label class="form-check-label" for="symptom<?php echo $symptom['symptom_id']; ?>">
                                    <?php echo htmlspecialchars($symptom['symptom_name']); ?>
                                </label>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                
                <button type="submit" class="btn btn-primary">Add Mapping</button>
                <a href="dashboard.php" class="btn btn-secondary">Back</a>
            </form>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
