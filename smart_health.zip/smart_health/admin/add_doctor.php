<?php
$css_path = '../css/style.css';
$home_path = '../index.php';
$base_path = '../';
include '../includes/header.php';
include '../config/db.php';

if(!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit();
}

$message = '';

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $specialization = $_POST['specialization'];
    $contact = $_POST['contact'];
    
    try {
        $stmt = $conn->prepare("INSERT INTO doctors (name, specialization, contact) VALUES (?, ?, ?)");
        $stmt->execute([$name, $specialization, $contact]);
        $message = '<div class="alert alert-success">Doctor added successfully!</div>';
    } catch(PDOException $e) {
        $message = '<div class="alert alert-danger">Error adding doctor!</div>';
    }
}
?>

<div class="container mt-4">
    <h2 class="text-center mb-4">Add Doctor</h2>
    <?php echo $message; ?>
    
    <div class="card" style="max-width: 600px; margin: 0 auto;">
        <div class="card-body">
            <form method="POST">
                <div class="mb-3">
                    <label>Doctor Name</label>
                    <input type="text" name="name" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label>Specialization</label>
                    <input type="text" name="specialization" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label>Contact Number</label>
                    <input type="text" name="contact" class="form-control" required>
                </div>
                <button type="submit" class="btn btn-primary">Add Doctor</button>
                <a href="dashboard.php" class="btn btn-secondary">Back</a>
            </form>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
