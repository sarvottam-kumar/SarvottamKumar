<?php
$css_path = '../css/style.css';
$home_path = '../index.php';
$base_path = '../';
include '../includes/header.php';
include '../config/db.php';

if(!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit();
}

$message = '';

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $disease_name = $_POST['disease_name'];
    $description = $_POST['description'];
    
    try {
        $stmt = $conn->prepare("INSERT INTO diseases (disease_name, description) VALUES (?, ?)");
        $stmt->execute([$disease_name, $description]);
        $message = '<div class="alert alert-success">Disease added successfully!</div>';
    } catch(PDOException $e) {
        $message = '<div class="alert alert-danger">Error adding disease!</div>';
    }
}
?>

<div class="container mt-4">
    <h2 class="text-center mb-4">Add Disease</h2>
    <?php echo $message; ?>
    
    <div class="card" style="max-width: 600px; margin: 0 auto;">
        <div class="card-body">
            <form method="POST">
                <div class="mb-3">
                    <label>Disease Name</label>
                    <input type="text" name="disease_name" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label>Description</label>
                    <textarea name="description" class="form-control" rows="4" required></textarea>
                </div>
                <button type="submit" class="btn btn-primary">Add Disease</button>
                <a href="dashboard.php" class="btn btn-secondary">Back</a>
            </form>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
