<?php
$css_path = '../css/style.css';
$home_path = '../index.php';
$base_path = '../';
include '../includes/header.php';
include '../config/db.php';

if(!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit();
}
?>

<div class="container admin-dashboard">
    <h2 class="text-center mb-4">Admin Dashboard</h2>
    <p class="text-center">Welcome, <?php echo $_SESSION['admin_name']; ?>!</p>
    
    <div class="row mt-4">
        <div class="col-md-3">
            <div class="card text-center">
                <div class="card-body">
                    <h5 class="card-title">Symptoms</h5>
                    <a href="view_symptoms.php" class="btn btn-primary btn-sm">View</a>
                    <a href="add_symptom.php" class="btn btn-success btn-sm">Add</a>
                </div>
            </div>
        </div>
        
        <div class="col-md-3">
            <div class="card text-center">
                <div class="card-body">
                    <h5 class="card-title">Diseases</h5>
                    <a href="view_diseases.php" class="btn btn-primary btn-sm">View</a>
                    <a href="add_disease.php" class="btn btn-success btn-sm">Add</a>
                </div>
            </div>
        </div>
        
        <div class="col-md-3">
            <div class="card text-center">
                <div class="card-body">
                    <h5 class="card-title">Doctors</h5>
                    <a href="view_doctors.php" class="btn btn-primary btn-sm">View</a>
                    <a href="add_doctor.php" class="btn btn-success btn-sm">Add</a>
                </div>
            </div>
        </div>
        
        <div class="col-md-3">
            <div class="card text-center">
                <div class="card-body">
                    <h5 class="card-title">Disease-Symptom</h5>
                    <a href="view_mapping.php" class="btn btn-primary btn-sm">View</a>
                    <a href="map_disease_symptom.php" class="btn btn-success btn-sm">Add</a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
