<?php
$css_path = '../css/style.css';
$home_path = '../index.php';
$base_path = '../';
include '../includes/header.php';
include '../config/db.php';

if(!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit();
}

// Handle delete
if(isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $stmt = $conn->prepare("DELETE FROM disease_symptom WHERE id = ?");
    $stmt->execute([$id]);
    header('Location: view_mapping.php');
    exit();
}

$query = "SELECT ds.id, d.disease_name, s.symptom_name 
          FROM disease_symptom ds
          JOIN diseases d ON ds.disease_id = d.disease_id
          JOIN symptoms s ON ds.symptom_id = s.symptom_id
          ORDER BY d.disease_name, s.symptom_name";
$mappings = $conn->query($query)->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="container mt-4">
    <h2 class="text-center mb-4">Disease-Symptom Mappings</h2>
    
    <table class="table table-bordered">
        <thead class="table-dark">
            <tr>
                <th>ID</th>
                <th>Disease</th>
                <th>Symptom</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach($mappings as $mapping): ?>
                <tr>
                    <td><?php echo $mapping['id']; ?></td>
                    <td><?php echo htmlspecialchars($mapping['disease_name']); ?></td>
                    <td><?php echo htmlspecialchars($mapping['symptom_name']); ?></td>
                    <td>
                        <a href="?delete=<?php echo $mapping['id']; ?>" 
                           class="btn btn-danger btn-sm" 
                           onclick="return confirm('Are you sure?')">Delete</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    
    <a href="dashboard.php" class="btn btn-secondary">Back to Dashboard</a>
</div>

<?php include '../includes/footer.php'; ?>
