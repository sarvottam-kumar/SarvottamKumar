<?php
$css_path = '../css/style.css';
$home_path = '../index.php';
$base_path = '../';
include '../includes/header.php';
include '../config/db.php';

if(!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit();
}

$message = '';

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $symptom_name = $_POST['symptom_name'];
    
    try {
        $stmt = $conn->prepare("INSERT INTO symptoms (symptom_name) VALUES (?)");
        $stmt->execute([$symptom_name]);
        $message = '<div class="alert alert-success">Symptom added successfully!</div>';
    } catch(PDOException $e) {
        $message = '<div class="alert alert-danger">Error adding symptom!</div>';
    }
}
?>

<div class="container mt-4">
    <h2 class="text-center mb-4">Add Symptom</h2>
    <?php echo $message; ?>
    
    <div class="card" style="max-width: 500px; margin: 0 auto;">
        <div class="card-body">
            <form method="POST">
                <div class="mb-3">
                    <label>Symptom Name</label>
                    <input type="text" name="symptom_name" class="form-control" required>
                </div>
                <button type="submit" class="btn btn-primary">Add Symptom</button>
                <a href="dashboard.php" class="btn btn-secondary">Back</a>
            </form>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
