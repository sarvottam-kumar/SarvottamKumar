<?php
$css_path = 'css/style.css';
$home_path = 'index.php';
$base_path = '';
include 'includes/header.php';
?>

<div class="container mt-5">
    <div class="row">
        <div class="col-md-6 offset-md-3">
            <div class="card">
                <div class="card-body">
                    <h2 class="text-center mb-4">Contact Us</h2>
                    <form>
                        <div class="mb-3">
                            <label>Name</label>
                            <input type="text" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label>Email</label>
                            <input type="email" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label>Message</label>
                            <textarea class="form-control" rows="5" required></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary">Send Message</button>
                    </form>
                    
                    <div class="mt-4">
                        <h5>Contact Information</h5>
                        <p><strong>Email:</strong> info@smarthealth.com</p>
                        <p><strong>Phone:</strong> +91-1234567890</p>
                        <p><strong>Address:</strong> Mumbai, India</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
