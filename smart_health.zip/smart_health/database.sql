-- Smart Health Prediction System Database
-- Create Database
CREATE DATABASE IF NOT EXISTS smart_health;
USE smart_health;

-- Table: users
CREATE TABLE users (
    user_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(50) NOT NULL,
    email VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    gender VARCHAR(15),
    mobile_no BIGINT
);

-- Table: admin
CREATE TABLE admin (
    admin_id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(50) NOT NULL
);

-- Insert default admin (username: admin, password: admin123)
INSERT INTO admin (username, password) VALUES ('admin', 'admin123');

-- Table: symptoms
CREATE TABLE symptoms (
    symptom_id INT PRIMARY KEY AUTO_INCREMENT,
    symptom_name VARCHAR(100) NOT NULL
);

-- Table: diseases
CREATE TABLE diseases (
    disease_id INT PRIMARY KEY AUTO_INCREMENT,
    disease_name VARCHAR(100) NOT NULL,
    description TEXT
);

-- Table: doctors
CREATE TABLE doctors (
    doctor_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(50) NOT NULL,
    specialization VARCHAR(50) NOT NULL,
    contact VARCHAR(15) NOT NULL
);

-- Table: disease_symptom (mapping table)
CREATE TABLE disease_symptom (
    id INT PRIMARY KEY AUTO_INCREMENT,
    disease_id INT NOT NULL,
    symptom_id INT NOT NULL,
    FOREIGN KEY (disease_id) REFERENCES diseases(disease_id) ON DELETE CASCADE,
    FOREIGN KEY (symptom_id) REFERENCES symptoms(symptom_id) ON DELETE CASCADE,
    UNIQUE KEY unique_mapping (disease_id, symptom_id)
);

-- Insert Symptoms
INSERT INTO symptoms (symptom_name) VALUES
('Fever'), ('Cough'), ('Cold'), ('Runny Nose'), ('Sneezing'),
('Body Pain'), ('Dry Cough'), ('Loss of Smell'), ('Joint Pain'), ('Fatigue'),
('High Fever'), ('Chills'), ('Weakness'), ('Headache'), ('Chest Pain'),
('Shortness of Breath'), ('Chest Tightness'), ('Nausea'), ('Sensitivity to Light'), ('Vomiting'),
('Diarrhea'), ('Abdominal Pain'), ('Heartburn'), ('Chest Discomfort'), ('Frequent Urination'),
('Increased Thirst'), ('Dizziness'), ('Pale Skin'), ('Swelling'), ('Stiffness'),
('Back Pain'), ('Muscle Stiffness'), ('Facial Pain'), ('Nasal Congestion'), ('Itchy Eyes'),
('Sore Throat'), ('Difficulty Swallowing'), ('Ear Pain'), ('Hearing Difficulty'), ('Burning Urination'),
('Lower Abdominal Pain'), ('Severe Back Pain'), ('Blood in Urine'), ('Yellow Skin'), ('Dark Urine'),
('Sadness'), ('Loss of Interest'), ('Sleep Problems'), ('Nervousness'), ('Rapid Heartbeat'),
('Sweating'), ('Difficulty Sleeping'), ('Irritability'), ('High Body Temperature'), ('Dry Mouth'),
('Reduced Urination');

-- Insert Diseases
INSERT INTO diseases (disease_name, description) VALUES
('Common Cold', 'A viral infection of the upper respiratory tract'),
('Flu', 'Influenza is a viral infection that attacks the respiratory system'),
('COVID-19', 'Coronavirus disease caused by SARS-CoV-2 virus'),
('Dengue', 'Mosquito-borne tropical disease caused by dengue virus'),
('Malaria', 'Disease caused by parasites transmitted through mosquito bites'),
('Typhoid', 'Bacterial infection caused by Salmonella typhi'),
('Pneumonia', 'Infection that inflames air sacs in one or both lungs'),
('Asthma', 'Condition in which airways narrow and swell'),
('Bronchitis', 'Inflammation of the lining of bronchial tubes'),
('Migraine', 'Severe headache with throbbing pain'),
('Food Poisoning', 'Illness caused by eating contaminated food'),
('Gastritis', 'Inflammation of the stomach lining'),
('Acidity', 'Condition where stomach acid flows back into esophagus'),
('Appendicitis', 'Inflammation of the appendix'),
('Diabetes', 'Disease that occurs when blood glucose is too high'),
('Hypertension', 'High blood pressure condition'),
('Heart Disease', 'Conditions that affect the heart'),
('Anemia', 'Condition with lack of healthy red blood cells'),
('Arthritis', 'Inflammation of one or more joints'),
('Back Pain Disorder', 'Pain affecting the back muscles and spine'),
('Sinusitis', 'Inflammation of tissue lining the sinuses'),
('Allergy', 'Immune system reaction to foreign substance'),
('Tonsillitis', 'Inflammation of the tonsils'),
('Ear Infection', 'Infection of the middle ear'),
('Urinary Tract Infection', 'Infection in any part of urinary system'),
('Kidney Stone', 'Hard deposits made of minerals and salts in kidneys'),
('Jaundice', 'Yellow discoloration of skin and eyes'),
('Depression', 'Mental health disorder with persistent sadness'),
('Anxiety Disorder', 'Mental health condition with excessive worry'),
('Insomnia', 'Sleep disorder making it hard to fall asleep'),
('Heat Stroke', 'Body overheating due to high temperature'),
('Dehydration', 'Body loses more fluids than intake');

-- Insert Doctors
INSERT INTO doctors (name, specialization, contact) VALUES
('Dr. Rajesh Kumar', 'General Physician', '9876543210'),
('Dr. Priya Sharma', 'Cardiologist', '9876543211'),
('Dr. Amit Patel', 'Pulmonologist', '9876543212'),
('Dr. Sneha Gupta', 'ENT Specialist', '9876543213'),
('Dr. Vikram Singh', 'Neurologist', '9876543214'),
('Dr. Anjali Verma', 'Psychiatrist', '9876543215'),
('Dr. Rahul Mehta', 'Orthopedic', '9876543216'),
('Dr. Kavita Reddy', 'Gastroenterologist', '9876543217'),
('Dr. Suresh Rao', 'Nephrologist', '9876543218'),
('Dr. Deepa Nair', 'Dermatologist', '9876543219');

-- Insert Disease-Symptom Mappings
-- Common Cold
INSERT INTO disease_symptom (disease_id, symptom_id) VALUES
(1, 3), (1, 4), (1, 5);

-- Flu
INSERT INTO disease_symptom (disease_id, symptom_id) VALUES
(2, 1), (2, 2), (2, 6);

-- COVID-19
INSERT INTO disease_symptom (disease_id, symptom_id) VALUES
(3, 1), (3, 7), (3, 8);

-- Dengue
INSERT INTO disease_symptom (disease_id, symptom_id) VALUES
(4, 11), (4, 9), (4, 10);

-- Malaria
INSERT INTO disease_symptom (disease_id, symptom_id) VALUES
(5, 1), (5, 12), (5, 6);

-- Typhoid
INSERT INTO disease_symptom (disease_id, symptom_id) VALUES
(6, 11), (6, 13), (6, 14);

-- Pneumonia
INSERT INTO disease_symptom (disease_id, symptom_id) VALUES
(7, 1), (7, 15), (7, 16);

-- Asthma
INSERT INTO disease_symptom (disease_id, symptom_id) VALUES
(8, 16), (8, 2), (8, 17);

-- Bronchitis
INSERT INTO disease_symptom (disease_id, symptom_id) VALUES
(9, 2), (9, 1), (9, 10);

-- Migraine
INSERT INTO disease_symptom (disease_id, symptom_id) VALUES
(10, 14), (10, 18), (10, 19);

-- Food Poisoning
INSERT INTO disease_symptom (disease_id, symptom_id) VALUES
(11, 20), (11, 21), (11, 22);

-- Gastritis
INSERT INTO disease_symptom (disease_id, symptom_id) VALUES
(12, 22), (12, 18), (12, 20);

-- Acidity
INSERT INTO disease_symptom (disease_id, symptom_id) VALUES
(13, 23), (13, 24), (13, 18);

-- Appendicitis
INSERT INTO disease_symptom (disease_id, symptom_id) VALUES
(14, 22), (14, 1), (14, 18);

-- Diabetes
INSERT INTO disease_symptom (disease_id, symptom_id) VALUES
(15, 25), (15, 26), (15, 10);

-- Hypertension
INSERT INTO disease_symptom (disease_id, symptom_id) VALUES
(16, 14), (16, 27), (16, 15);

-- Heart Disease
INSERT INTO disease_symptom (disease_id, symptom_id) VALUES
(17, 15), (17, 16), (17, 10);

-- Anemia
INSERT INTO disease_symptom (disease_id, symptom_id) VALUES
(18, 10), (18, 27), (18, 28);

-- Arthritis
INSERT INTO disease_symptom (disease_id, symptom_id) VALUES
(19, 9), (19, 29), (19, 30);

-- Back Pain Disorder
INSERT INTO disease_symptom (disease_id, symptom_id) VALUES
(20, 31), (20, 32), (20, 10);

-- Sinusitis
INSERT INTO disease_symptom (disease_id, symptom_id) VALUES
(21, 14), (21, 33), (21, 34);

-- Allergy
INSERT INTO disease_symptom (disease_id, symptom_id) VALUES
(22, 5), (22, 4), (22, 35);

-- Tonsillitis
INSERT INTO disease_symptom (disease_id, symptom_id) VALUES
(23, 36), (23, 1), (23, 37);

-- Ear Infection
INSERT INTO disease_symptom (disease_id, symptom_id) VALUES
(24, 38), (24, 1), (24, 39);

-- Urinary Tract Infection
INSERT INTO disease_symptom (disease_id, symptom_id) VALUES
(25, 40), (25, 25), (25, 41);

-- Kidney Stone
INSERT INTO disease_symptom (disease_id, symptom_id) VALUES
(26, 42), (26, 18), (26, 43);

-- Jaundice
INSERT INTO disease_symptom (disease_id, symptom_id) VALUES
(27, 44), (27, 45), (27, 10);

-- Depression
INSERT INTO disease_symptom (disease_id, symptom_id) VALUES
(28, 46), (28, 47), (28, 48);

-- Anxiety Disorder
INSERT INTO disease_symptom (disease_id, symptom_id) VALUES
(29, 49), (29, 50), (29, 51);

-- Insomnia
INSERT INTO disease_symptom (disease_id, symptom_id) VALUES
(30, 52), (30, 10), (30, 53);

-- Heat Stroke
INSERT INTO disease_symptom (disease_id, symptom_id) VALUES
(31, 54), (31, 27), (31, 14);

-- Dehydration
INSERT INTO disease_symptom (disease_id, symptom_id) VALUES
(32, 55), (32, 10), (32, 56);
