<?php
$css_path = 'css/style.css';
$home_path = 'index.php';
$base_path = '';
include 'includes/header.php';
?>

<div class="hero-section">
    <div class="container">
        <h1>Smart Health Prediction System</h1>
        <p>Select symptoms and get instant health guidance.</p>
        <a href="user/login.php" class="btn btn-get-started">Get Started</a>
        
        <svg class="health-icon" viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg "> -->
            <!-- Heart Shape -->
            <path d="M100,170 C100,170 30,120 30,80 C30,60 45,45 65,45 C80,45 90,55 100,70 C110,55 120,45 135,45 C155,45 170,60 170,80 C170,120 100,170 100,170 Z" 
                  fill="#e57373" stroke="#c62828" stroke-width="3"/> -->
            <!-- Medical Cross -->
            <rect x="85" y="65" width="30" height="15" fill="#4db6ac" stroke="#00796b" stroke-width="2"/>
            <rect x="92.5" y="57.5" width="15" height="30" fill="#4db6ac" stroke="#00796b" stroke-width="2"/>
            <!-- Hand -->
            <!-- <ellipse cx="100" cy="150" rx="40" ry="15" fill="#ffab91" stroke="#e64a19" stroke-width="2"/>
            <rect x="60" y="135" width="15" height="40" fill="#ffab91" stroke="#e64a19" stroke-width="2" rx="5"/> -->
        </svg> 
    </div>
</div>

<div class="how-it-works">
    <div class="container">
        <h2>How It Works</h2>
        <div class="row">
            <div class="col-md-4">
                <div class="step-card">
                    <h5>Step 1</h5>
                    <p>Register & Login</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="step-card">
                    <h5>Step 2</h5>
                    <p>Select Symptoms</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="step-card">
                    <h5>Step 3</h5>
                    <p>View Result & Specialist Doctor</p>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
