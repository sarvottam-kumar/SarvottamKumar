<?php
$css_path = '../css/style.css';
$home_path = '../index.php';
$base_path = '../';
include '../includes/header.php';
include '../config/db.php';

$stmt = $conn->query("SELECT * FROM doctors ORDER BY name");
$doctors = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="container mt-4">
    <h2 class="text-center mb-4">Available Doctors</h2>
    
    <div class="row">
        <?php foreach($doctors as $doctor): ?>
            <div class="col-md-4 mb-3">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo htmlspecialchars($doctor['name']); ?></h5>
                        <p class="card-text">
                            <strong>Specialization:</strong> <?php echo htmlspecialchars($doctor['specialization']); ?><br>
                            <strong>Contact:</strong> <?php echo htmlspecialchars($doctor['contact']); ?>
                        </p>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
    
    <?php if(isset($_SESSION['user_id'])): ?>
        <div class="text-center mt-3">
            <a href="../user/select_symptoms.php" class="btn btn-primary">Back to Prediction</a>
        </div>
    <?php endif; ?>
</div>

<?php include '../includes/footer.php'; ?>
