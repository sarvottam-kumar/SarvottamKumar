<?php
$css_path = '../css/style.css';
$home_path = '../index.php';
$base_path = '../';
include '../includes/header.php';
include '../config/db.php';

if(!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$stmt = $conn->query("SELECT * FROM symptoms ORDER BY symptom_name");
$symptoms = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="symptom-selection">
    <h2 class="text-center mb-4">Select Your Symptoms</h2>
    <p class="text-center">Please select all symptoms you are experiencing:</p>
    
    <form method="POST" action="result.php">
        <div class="row">
            <?php foreach($symptoms as $symptom): ?>
                <div class="col-md-6">
                    <div class="form-check symptom-checkbox">
                        <input class="form-check-input" type="checkbox" name="symptoms[]" 
                               value="<?php echo $symptom['symptom_id']; ?>" 
                               id="symptom<?php echo $symptom['symptom_id']; ?>">
                        <label class="form-check-label" for="symptom<?php echo $symptom['symptom_id']; ?>">
                            <?php echo htmlspecialchars($symptom['symptom_name']); ?>
                        </label>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        <div class="text-center mt-4">
            <button type="submit" class="btn btn-primary">Get Prediction</button>
        </div>
    </form>
</div>

<?php include '../includes/footer.php'; ?>
