<?php
$css_path = '../css/style.css';
$home_path = '../index.php';
$base_path = '../';
include '../includes/header.php';
include '../config/db.php';

$message = '';

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $gender = $_POST['gender'];
    $mobile_no = $_POST['mobile_no'];
    
    try {
        $stmt = $conn->prepare("INSERT INTO users (name, email, password, gender, mobile_no) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$name, $email, $password, $gender, $mobile_no]);
        $message = '<div class="alert alert-success">Registration successful! Please login.</div>';
    } catch(PDOException $e) {
        $message = '<div class="alert alert-danger">Error: Email already exists!</div>';
    }
}
?>

<div class="register-container">
    <h2 class="text-center mb-4">User Registration</h2>
    <?php echo $message; ?>
    <form method="POST">
        <div class="mb-3">
            <label>Name</label>
            <input type="text" name="name" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Email</label>
            <input type="email" name="email" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Password</label>
            <input type="password" name="password" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Gender</label>
            <select name="gender" class="form-control" required>
                <option value="">Select Gender</option>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
                <option value="Other">Other</option>
            </select>
        </div>
        <div class="mb-3">
            <label>Mobile Number</label>
            <input type="text" name="mobile_no" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-primary">Register</button>
    </form>
    <p class="text-center mt-3">Already have an account? <a href="login.php">Login here</a></p>
</div>

<?php include '../includes/footer.php'; ?>
