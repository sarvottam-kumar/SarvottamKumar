<?php
$css_path = '../css/style.css';
$home_path = '../index.php';
$base_path = '../';
include '../includes/header.php';
include '../config/db.php';

if(!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$predicted_disease = null;
$message = '';

if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['symptoms'])) {
    $selected_symptoms = $_POST['symptoms'];
    
    if(count($selected_symptoms) > 0) {
        // Create placeholders for IN clause
        $placeholders = str_repeat('?,', count($selected_symptoms) - 1) . '?';
        
        // Query to find disease with maximum matching symptoms
        $query = "SELECT d.disease_id, d.disease_name, d.description, COUNT(*) as match_count
                  FROM diseases d
                  JOIN disease_symptom ds ON d.disease_id = ds.disease_id
                  WHERE ds.symptom_id IN ($placeholders)
                  GROUP BY d.disease_id
                  ORDER BY match_count DESC
                  LIMIT 1";
        
        $stmt = $conn->prepare($query);
        $stmt->execute($selected_symptoms);
        $predicted_disease = $stmt->fetch(PDO::FETCH_ASSOC);
    } else {
        $message = '<div class="alert alert-warning">Please select at least one symptom!</div>';
    }
}
?>

<div class="result-container">
    <h2 class="text-center mb-4">Prediction Result</h2>
    
    <?php if($message): ?>
        <?php echo $message; ?>
        <div class="text-center mt-3">
            <a href="select_symptoms.php" class="btn btn-primary">Go Back</a>
        </div>
    <?php elseif($predicted_disease): ?>
        <div class="alert alert-info">
            <h4>Possible Disease: <?php echo htmlspecialchars($predicted_disease['disease_name']); ?></h4>
            <p><strong>Description:</strong> <?php echo htmlspecialchars($predicted_disease['description']); ?></p>
            <p><strong>Matching Symptoms:</strong> <?php echo $predicted_disease['match_count']; ?></p>
        </div>
        
        <div class="alert alert-warning">
            <strong>Disclaimer:</strong> This is only a prediction based on selected symptoms. 
            Please consult a doctor for proper diagnosis and treatment.
        </div>
        
        <div class="text-center mt-3">
            <a href="../doctor/view_doctors.php" class="btn btn-success">View Doctors</a>
            <a href="select_symptoms.php" class="btn btn-primary">New Prediction</a>
        </div>
    <?php else: ?>
        <div class="alert alert-warning">
            No matching disease found. Please consult a doctor.
        </div>
        <div class="text-center mt-3">
            <a href="select_symptoms.php" class="btn btn-primary">Try Again</a>
        </div>
    <?php endif; ?>
</div>

<?php include '../includes/footer.php'; ?>
